module.exports={
    secret:'kondiiiii',
    cloud_name: 'kondipress',
    api_key : 272156987941533,
    api_secret : 'hyTLYt7j7_3aeQJh68n0QgZ9t8c'
};

