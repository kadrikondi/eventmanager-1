import React from "react";
import {
  MDBBtn,
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBInput,
  MDBCheckbox,
  MDBIcon,
} from "mdb-react-ui-kit";

const Landing = () => {
  return (
    <MDBContainer fluid className="p-4" style={{ backgroundColor: "#F5F5F5" }}>
      <MDBRow>
        <MDBCol
          md="8"
          className="text-center text-md-start d-flex flex-column justify-content-center"
        >
          <h1 className="my-5 display-3 fw-bold ls-tight px-3">
            Book For Best
            <br />
            <span className="text-primary">Events Center in One click</span>
          </h1>

          <p className="px-3" style={{ color: "hsl(217, 10%, 50.8%)" }}>
            Welcome to our premier event center booking platform, where your
            dream celebration begins! Discover the perfect venue effortlessly
            with our user-friendly app, designed to simplify your event planning
            journey. Whether you're organizing a wedding, corporate event, or a
            special celebration, we've curated a diverse selection of top-tier
            event centers tailored to your every need. Browse through stunning
            venues, check real-time availability, and secure your booking with
            just a few clicks. Our platform not only streamlines the process but
            also offers expert advice, ensuring your event is nothing short of
            extraordinary. Say goodbye to stress and hello to seamless event
            planning. Let's transform your visions into unforgettable moments
            together. Start exploring now and let the magic of your event unfold
            effortlessly.
          </p>
        </MDBCol>

        <MDBCol md="4">
          <MDBCard className="my-5">
            <MDBCardBody className="p-5">
              <MDBInput
                wrapperClass="mb-4"
                label="Email"
                id="form1"
                type="email"
              />
              <MDBInput
                wrapperClass="mb-4"
                label="Password"
                id="form1"
                type="password"
              />

              <div className="d-flex justify-content-center mb-4"></div>

              <MDBBtn className="w-100 mb-4" size="md">
                Sign In
              </MDBBtn>

              <div className="text-center">
                <p>
                  or Not a User <a href="http://"> Sign up </a>
                </p>

                <MDBBtn
                  tag="a"
                  color="none"
                  className="mx-3"
                  style={{ color: "#1266f1" }}
                >
                  <MDBIcon fab icon="facebook-f" size="sm" />
                </MDBBtn>

                <MDBBtn
                  tag="a"
                  color="none"
                  className="mx-3"
                  style={{ color: "#1266f1" }}
                >
                  <MDBIcon fab icon="twitter" size="sm" />
                </MDBBtn>

                <MDBBtn
                  tag="a"
                  color="none"
                  className="mx-3"
                  style={{ color: "#1266f1" }}
                >
                  <MDBIcon fab icon="google" size="sm" />
                </MDBBtn>

                <MDBBtn
                  tag="a"
                  color="none"
                  className="mx-3"
                  style={{ color: "#1266f1" }}
                >
                  <MDBIcon fab icon="github" size="sm" />
                </MDBBtn>
              </div>
            </MDBCardBody>
          </MDBCard>
        </MDBCol>
      </MDBRow>
    </MDBContainer>
  );
};

export default Landing;
